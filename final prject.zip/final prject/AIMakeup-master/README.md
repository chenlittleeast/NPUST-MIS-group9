# AIMakeup
AI make up based on face-detection
# Example
![example](./example.gif)
